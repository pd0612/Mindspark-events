# MindSpark22-Events

A repository for Events page of COEP's Techfest Mindspark22, now live at
https://www.mind-spark.org/Events/
